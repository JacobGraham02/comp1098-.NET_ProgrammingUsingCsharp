﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _2_2_MaintainStudentScores
{
    public partial class frmUpdateScore : Form
    {
        public frmUpdateScore()
        {
            InitializeComponent();
        }

        private void btnCancelScore_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnUpdateScore_Click(object sender, EventArgs e)
        {

        }

        private void frmUpdateScore_Load(object sender, EventArgs e)
        {

        }
    }
}
